HABIT TRACKER 30 HARI — PROYEK ANDROID

Isi folder ini adalah source project Android Studio yang membungkus file HTML asli ke dalam aplikasi Android WebView.
Checklist, statistik, penyimpanan lokal, dan tampilan mobile menggunakan file HTML yang disertakan.
Ekspor CSV di APK akan menyimpan file ke folder Download.

CARA MEMBUAT APK (perlu komputer/laptop):
1. Instal Android Studio dari situs resmi Android Developer.
2. Ekstrak ZIP ini.
3. Buka Android Studio > Open, lalu pilih folder HabitTrackerAndroid.
4. Tunggu proses Gradle Sync dan instal komponen SDK jika diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik Locate pada notifikasi Build. File biasanya berada di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan APK ke HP Android, buka file tersebut, lalu izinkan instalasi dari sumber ini jika diminta.

CATATAN:
- Ini source project, bukan file APK yang sudah dikompilasi.
- Build APK memerlukan Android SDK dan Android Gradle Plugin; keduanya diunduh melalui Android Studio.
- Data tersimpan lokal di perangkat aplikasi. Menghapus data aplikasi dapat menghapus progres.
